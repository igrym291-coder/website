import os
from flask import Flask, send_from_directory

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)


@app.route("/")
def index():
    return send_from_directory(BASE, "index.html")


# Здесь позже можно добавить API (Supabase, база данных, AI Mentor):
# @app.post("/api/mentor")
# def mentor(): ...

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
