# SkillForge

Структура:
    skillforge/
      app.py            # Flask-сервер
      index.html        # весь сайт (React + стили внутри)
      requirements.txt
      Procfile          # для Render / Railway / Heroku

## Запуск на своём компьютере
    pip install -r requirements.txt
    python app.py
Открой http://localhost:5000

## Выкладка в интернет (пример: Render.com)
1. Загрузи папку на GitHub.
2. Render -> New Web Service -> выбери репозиторий.
3. Build command:  pip install -r requirements.txt
4. Start command:  gunicorn app:app
5. Получишь публичную ссылку https://<имя>.onrender.com
Свой домен подключается в настройках сервиса (Custom Domain).

Важно: сайту нужен интернет у посетителя (React и шрифты грузятся с CDN).
